from Animal import *

class Ular(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, design, racun):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.design = design
        self.racun = racun

    def cetak_Ular(self):
        super().cetak()
        print("Design \t\t\t\t:", self.design, 
        "\nRacun \t\t\t\t:", self.racun)

anaconda = Ular("Anaconda", "Kambing", "Amazon", "Bertelur", "Batik Solo", "Tidak Berbisa")
anaconda.cetak_Ular()
sawah = Ular("Sawah", "Tikus", "Sawah", "Bertelur", "corak hijau", "Tidak Berbisa")
sawah.cetak_Ular()


