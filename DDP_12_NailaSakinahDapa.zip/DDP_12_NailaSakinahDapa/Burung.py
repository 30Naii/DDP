from Animal import *

class Burung(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, jenis, warna, bunyi):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.jenis = jenis
        self.warna = warna 
        self.bunyi = bunyi

    def cetak_Burung(self):
        super().cetak()
        print("Jenis \t\t\t\t:", self.jenis, 
        "\nWarna \t\t\t\t:", self.warna,
        "\nBunyi \t\t\t\t:", self.bunyi)

Kenari = Burung("Kenari", "Biji-bijian", "Pohon", "Bertelur", "Burung sangkar", "Kuning", "Tweeee")
Kenari.cetak_Burung()
Hantu = Burung("Hantu", "Biji-bijian", "Pohon", "Bertelur", "Burung sangkar", "Hitam abu-abu", "krukkkk krukk")
Hantu.cetak_Burung()
