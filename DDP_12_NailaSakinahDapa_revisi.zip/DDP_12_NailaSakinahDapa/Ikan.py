from Animal import *

class Ikan(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, jenis,warna,):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.jenis = jenis
        self.warna = warna

    def cetak_Ikan(self):
        super().cetak()
        print("Jenis \t\t\t\t:", self.jenis, 
        "\nWarna \t\t\t\t:", self.warna )

nemo = Ikan("Nemo", "plankton", "air laut", "Bertelur", "ikan badut", "putih corak oren")
nemo.cetak_Ikan()
hiu = Ikan("Hiu", "planton dan ikan-ikan kecil", "air laut", "Bertelur", "ikan bertulang rawan", "abu tua")
hiu.cetak_Ikan()
